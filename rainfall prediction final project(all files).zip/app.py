import streamlit as st
import pandas as pd
import numpy as np
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
# ==========================
# Load required models
# ==========================
rf_model = joblib.load("rainfall_rf_classifier.pkl")
lr_model = joblib.load("rainfall_lr_classifier.pkl")
   # fit it on your training data

scaler = joblib.load("rainfall_scaler.pkl")   # if you saved your StandardScaler

# ==========================
# Page config
# ==========================
st.set_page_config(page_title="Rainfall Prediction App")
st.title("🌧️ Rainfall Prediction Based on Temperature & Year")
st.markdown("This app predicts rainfall categories (Low, Medium, High) based on **Year** and **Temperature (°C)**.")

# ==========================
# Sidebar inputs
# ==========================
st.sidebar.header("Input Parameters")

def get_user_input():
    year = st.sidebar.number_input("Year", min_value=1900, max_value=2100, value=2020)
    temp = st.sidebar.number_input("Temperature (°C)", min_value=-10.0, max_value=50.0, value=25.0, step=0.1)

    data = pd.DataFrame({
        'YEAR': [year],
        'Temperature (°C)': [temp]
    })
    return data

input_data = get_user_input()


scaled_input = scaler.transform(input_data)


st.subheader("🔍 Predictions")

rf_pred = rf_model.predict(scaled_input)[0]
lr_pred = lr_model.predict(scaled_input)[0]

st.write(f"**Random Forest Prediction:** {rf_pred}")
st.write(f"**Logistic Regression Prediction:** {lr_pred}")


st.subheader("📊 Input Data Overview")
st.write(input_data)

st.markdown("---")
